<?php

namespace React\Async;

// @codeCoverageIgnoreStart
if (!\function_exists(__NAMESPACE__ . '\\parallel')) {
    require __DIR__ . '/functions.php';
}
// @codeCoverageIgnoreEnd
